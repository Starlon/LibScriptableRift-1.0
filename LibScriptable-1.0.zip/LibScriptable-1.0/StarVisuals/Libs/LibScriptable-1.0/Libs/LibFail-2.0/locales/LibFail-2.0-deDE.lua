﻿local L = LibStub("AceLocale-3.0"):NewLocale("LibFail-2.0", "deDE")
if not L then return end

L["%s fails at %s"] = "%s versagte bei %s" -- Needs review
L["%s fails at %s (%s)"] = "%s versagte bei %s (%s)" -- Needs review
L["'s Fail Events"] = "s misslungene Ereignisse"
-- L["'s Failers"] = "'s Failers"
-- L["'s Fails"] = "'s Fails"
-- L["Damage Constraint"] = "Damage Constraint"
-- L["Fail"] = "Fail"
L["Fails"] = "Misslingen"
-- L["Tanks Dont Fail"] = "Tanks Dont Fail"
-- L["Tick Constraint"] = "Tick Constraint"
-- L["Time Constraint - High"] = "Time Constraint - High"
-- L["Time Constraint - Low"] = "Time Constraint - Low"
L["casting"] = "casten"
L["dispelling"] = "entzaubern"
L["moving"] = "Bewegen"
-- L["not attacking"] = "not attacking"
L["not being at the wrong place"] = "am falschem Ort sein"
L["not casting"] = "Nicht zaubern"
L["not dispelling"] = "Nicht entzaubern"
L["not moving"] = "nicht bewegen"
L["not spreading"] = "Nicht verbreiten"
L["spreading"] = "verbreiten"
-- L["switching"] = "switching"
