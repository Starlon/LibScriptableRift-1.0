﻿local L = LibStub("AceLocale-3.0"):NewLocale("LibFail-2.0", "zhTW")
if not L then return end

L["%s fails at %s"] = "%s 失誤于 %s"
L["%s fails at %s (%s)"] = "%s 失誤于 %s (%s)"
L["'s Fail Events"] = "的失誤事件"
-- L["'s Failers"] = "'s Failers"
-- L["'s Fails"] = "'s Fails"
-- L["Damage Constraint"] = "Damage Constraint"
L["Fail"] = "失誤"
L["Fails"] = "失誤"
L["Tanks Dont Fail"] = "坦克不算做失誤" -- Needs review
-- L["Tick Constraint"] = "Tick Constraint"
-- L["Time Constraint - High"] = "Time Constraint - High"
-- L["Time Constraint - Low"] = "Time Constraint - Low"
L["casting"] = "施放"
L["dispelling"] = "驅散"
L["moving"] = "移動"
L["not attacking"] = "不能攻擊"
L["not being at the wrong place"] = "不在錯誤的位置" -- Needs review
L["not casting"] = "停止施法"
L["not dispelling"] = "禁止驅散"
L["not moving"] = "沒跑開"
L["not spreading"] = "沒散開"
L["spreading"] = "散開"
L["switching"] = "交換"
