local MAJOR, MINOR = "LibFail-2.0", tonumber("44") or 999

assert(LibStub, MAJOR.." requires LibStub")

local lib = LibStub:NewLibrary(MAJOR, MINOR)
if not lib then return end
--[===[@debug@
-- ### debug
lf = lib
--@end-debug@]===]
lib.callbacks = lib.callbacks or LibStub("CallbackHandler-1.0"):New(lib)
local callbacks = lib.callbacks

lib.frame = lib.frame or CreateFrame("Frame")
local frame = lib.frame

local LGT = LibStub:GetLibrary("LibGroupTalents-1.0")

local BB = LibStub("LibBabble-Boss-3.0"):GetUnstrictLookupTable()
local BZ = LibStub("LibBabble-Zone-3.0"):GetUnstrictLookupTable()

frame:RegisterEvent("PLAYER_ENTERING_WORLD")

-------------------------------------------------------------------------
-- LOCALES
-------------------------------------------------------------------------
local L = LibStub("AceLocale-3.0"):NewLocale("LibFail-2.0", "enUS", true)

-- ### remember to remove debug events
--L["Caleb's fail"] = true
--L["Holy light lulz"] = true

-- Constraint Names
L["Damage Constraint"] = true
L["Tick Constraint"] = true
L["Time Constraint - Low"] = true
L["Time Constraint - High"] = true

-- Fail Types
L["not moving"] = true
L["moving"] = true
L["not spreading"] = true
L["spreading"] = true
L["dispelling"] = true
L["not dispelling"] = true
L["not being at the wrong place"] = true
L["not casting"] = true
L["not attacking"] = true
L["casting"] = true
L["switching"] = true

-- You can request strings to be added to the common strings in a ticket at the addons page
-- Common strings
L["Fail"] = true
L["Fails"] = true
L["%s fails at %s"] = true
L["%s fails at %s (%s)"] = true
L["'s Fails"] = true
L["'s Failers"] = true
L["'s Fail Events"] = true
L["Tanks Dont Fail"] = true

local L = LibStub("AceLocale-3.0"):GetLocale("LibFail-2.0")

-- Fail Event Names
-- Naming scheme for fail events:
-- Fail_Zone Name_Boss Name_Ability Name
-- only add non general events to the list
-- ["Fail_Zone Name_Boss Name_Ability Name"] = { { spellId list }, FAIL_TYPE, event name or spellId, description or spellId, true if tanks do not fail },
-- Some of these spellids need verification, but are probably right.
local failEvents = {
	-- ### remember to remove debug events
	--["Fail_Glob -'bal_Maat_HL"] = { { 635 }, "FAIL_TYPE_NOTCASTING", 635, L["Holy light lulz"], true },
	--["Fail_Glob -'bal_Ca 'leb_Dismiss Pet"] = { { 2641 }, "FAIL_TYPE_NOTCASTING", L["Caleb's fail"], L["Caleb's fail"] },
	["Fail_The Bastion of Twilight_Valiona and Theralion_Deep Breath"] = { { 86059 }, "FAIL_TYPE_MOVING", 86059, 86059 },
	["Fail_The Bastion of Twilight_Valiona and Theralion_Twilight Meteorite"] = { { 86014, 92863, 92864, 92865 }, "FAIL_TYPE_WRONGPLACE", 92864, 92864 },
	["Fail_The Bastion of Twilight_Valiona and Theralion_Devouring Flames"] = { { 86844, 92872, 92873, 92874 }, "FAIL_TYPE_MOVING", 86844, 86844 },
	["Fail_The Bastion of Twilight_Ascendant Council_Flame Torrent"] = { { 88558, 92516, 92517, 92518 }, "FAIL_TYPE_WRONGPLACE", 82777, 82777, true },
	["Fail_The Bastion of Twilight_Ascendant Council_Frozen"] = { { 82772, 92503, 92504, 92505 }, "FAIL_TYPE_MOVING", 92504, 92504 },
	["Fail_The Bastion of Twilight_Ascendant Council_Flame Strike"] = { { 92215 }, "FAIL_TYPE_MOVING", 92215, 92215 },
	["Fail_The Bastion of Twilight_Ascendant Council_Lava Plume"] = { { 84912, 92491, 92492, 92493 }, "FAIL_TYPE_MOVING", 92491, 92491 },
	["Fail_The Bastion of Twilight_Cho'gall_Blood"] = { {}, nil, 93174, 93174 },
	["Fail_Blackwing Descent_Maloriak_Consuming Flames"] = { { 77786, 92972, 92973, 92971 }, "FAIL_TYPE_MOVING", 77786, 77786, true },
	["Fail_Blackwing Descent_Maloriak_Scorching Blast"] = { { 77679, 92968, 92969, 92970 }, "FAIL_TYPE_WRONGPLACE", 77679, 77679, true },
	["Fail_Blackwing Descent_Maloriak_Engulfing Darkness"] = { { 92787, 92981, 92982, 92983 }, "FAIL_TYPE_MOVING", 92983, 92983, true },
	["Fail_Blackwing Descent_Maloriak_Dark Sludge"] = { { 92930, 92986, 92987, 92988 }, "FAIL_TYPE_MOVING", 92988, 92988 },
	["Fail_Blackwing Descent_Maloriak_Magma Jets"] = { { 93014, 93015, 93016, 93038, 93039, 93040 }, "FAIL_TYPE_MOVING", 93016, 93016 },
	["Fail_Blackwing Descent_Maloriak_Absolute Zero"] = { { 78208, 93041, 93042, 93043 }, "FAIL_TYPE_MOVING", 93043, 93043 },
	["Fail_Blackwing Descent_Atramedes_Sonic Breath"] = { { 78100, 92407, 92408, 92409 }, "FAIL_TYPE_MOVING", 92408, 92408 },
	["Fail_Blackwing Descent_Atramedes_Sonar Pulse"] = { { 77675, 92417, 92418, 92419 }, "FAIL_TYPE_MOVING", 92418, 92418 },
	["Fail_Blackwing Descent_Nefarian_Shadow Of Cowardice"] = { { 79353 }, "FAIL_TYPE_MOVING", 79353, 79353 },
	["Fail_Blackwing Descent_Nefarian_Tail Lash"] = { { 77827, 94128, 94129, 94130 }, "FAIL_TYPE_WRONGPLACE", 94129, 94129 },
	["Fail_Blackwing Descent_Nefarian_Magma"] = { { 81118, 94073, 94074, 94075 }, "FAIL_TYPE_MOVING", 94073, 94073 },
	["Fail_Blackwing Descent_Nefarian_Shadowblaze"] = { { 81007, 94085, 94086, 94087 }, "FAIL_TYPE_MOVING", 94085, 94085, true },
	["Fail_Throne of the Four Winds_Al'Akir_Squall Line"] = { { 87856, 93283, 93284, 93285 }, "FAIL_TYPE_MOVING", 93283, (GetSpellInfo(1680)) },
	["Fail_Throne of the Four Winds_Conclave of Wind_Wind Blast"] = { { 85483, 93138, 93139, 93140 }, "FAIL_TYPE_MOVING", 93139, 93139 },
	["Fail_Throne of the Four Winds_Conclave of Wind_Toxic Spores"] = { { 86282, 93120, 93121, 93122 }, "FAIL_TYPE_MOVING", 93121, 93121 },
	["Fail_Throne of the Four Winds_Conclave of Wind_Permafrost"] = { { 86081, 93126, 93127, 93128 }, "FAIL_TYPE_WRONGPLACE", 93128, 93128, true },
	["Fail_Blackwing Descent_Omnotron Defense System_Barrier"] = { {}, nil, 91517, 91517 },
	["Fail_Blackwing Descent_Omnotron Defense System_Chemical Cloud"] = { { 91471, 91472, 91473 }, "FAIL_TYPE_MOVING", 91472, 91472 },
	["Fail_Blackwing Descent_Omnotron Defense System_Arcane Blowback"] = { { 91879, 91880 }, "FAIL_TYPE_MOVING", 91880, 91880 },
	["Fail_Blackwing Descent_Omnotron Defense System_Poison Bomb"] = { {91499, 91500 }, "FAIL_TYPE_MOVING", 91499, 91499 },
	["Fail_Blackwing Descent_Magmaw_Parasitic Infection"] = { { 78941, 91913, 94678, 94679 }, "FAIL_TYPE_MOVING", 91913, 91913 },
	["Fail_Blackwing Descent_Magmaw_Pillar of Flame"] = { { 77971, 91918, 91929, 91930 }, "FAIL_TYPE_MOVING", 91918, 91918 },
	["Fail_Blackwing Descent_Magmaw_Ignition"] = { { 92131, 92196, 92197, 92198 }, "FAIL_TYPE_MOVING", 92198, 92198 },
	["Fail_Blackwing Descent_Magmaw_Massive Crash"] = { { 88287, 91914, 91921, 91922 }, "FAIL_TYPE_MOVING", 91922, 91922 },
	["Fail_The Bastion of Twilight_Cho'gall_Blaze"] = { { 81538, 93212, 93213 }, "FAIL_TYPE_MOVING", 93213, 93213 },
	["Fail_The Bastion of Twilight_Cho'gall_Corrupting Crash"] = { { 81689, 93184, 93185, 93186 }, "FAIL_TYPE_MOVING", 93185, 93185 },
	["Fail_Blackwing Descent_Atramedes_Sonar Bomb"] = { { 92553, 92554, 92555, 92556 }, "FAIL_TYPE_MOVING", 92555, 92555 },
	["Fail_The Bastion of Twilight_Sinestra_Twilight Slicer"] = { { 92954 }, "FAIL_TYPE_MOVING", 92954, 92954 },
	["Fail_The Bastion of Twilight_Sinestra_Twilight Extinction"] = { { 86226 }, "FAIL_TYPE_MOVING", 86226, 86226 },
	["Fail_The Bastion of Twilight_Sinestra_Twilight Pulse"] = { { 92959 }, "FAIL_TYPE_MOVING", 92959, 92959 },
}

-- ["Fail_Zone Name_Boss Name_Ability Name"] = { { spellId list }, FAIL_TYPE, event name or spellId, description or spellId, true if tanks do not fail, true if its only overkill },
-- Don't forget to add damageConstraint at the globals section if necesary
local generalDamageFail = {
	["Fail_The Bastion of Twilight_Halfus Wyrmbreaker_Fireball Barrage"] = { { 83734, 86154, 86153 }, "FAIL_TYPE_MOVING", 83734, 83734 },
	["Fail_The Bastion of Twilight_Ascendant Council_Glaciate"] = { { 82746, 92506, 92507, 92508 }, "FAIL_TYPE_MOVING", 92506, 92506 },
	["Fail_The Bastion of Twilight_Ascendant Council_Thundershock"] = { { 83067, 92469, 92470, 92471 }, "FAIL_TYPE_MOVING", 92469, 92469, nil, true },
	["Fail_The Bastion of Twilight_Ascendant Council_Quake"] = { {  83565, 92544, 92545, 92546 }, "FAIL_TYPE_MOVING", 92544, 92544, nil, true },
	["Fail_The Bastion of Twilight_Ascendant Council_Eruption"] = { { 83692, 92534, 92535, 92536 }, "FAIL_TYPE_MOVING", 92535, 92535 },
}

-- Populate failEvents with simple fails so we don't have to add them more than once
-- ... in case we decide to add more general fail types
local function PopulateFailEvents(...)
	for i=1, select("#", ...) do
		for k, v in pairs(select(i, ...)) do
			failEvents[k] = v
		end
	end
end
PopulateFailEvents(generalDamageFail)

local function TableLookup(item, table)
	for i=1, #table do
		if table[i] == item then return i end
	end
	return false
end

local zoneList, bossList, zoneBosses = {}, {}, {}
for k, v in pairs(failEvents) do
	local s = k:match("_.*_"):match("[^_].*[^_]")
	local z = s:match(".*_"):gsub("_","")
	local b = s:match("_.*"):gsub("_","")

	if not zoneList[z] then zoneList[z] = {} end
	table.insert(zoneList[z], k)

	if not bossList[b] then bossList[b] = {} end
	table.insert(bossList[b], k)

	if not zoneBosses[z] then zoneBosses[z] = {} end
	if not TableLookup(b, zoneBosses[z]) then table.insert(zoneBosses[z], b) end
end

local debuffs = {
	(GetSpellInfo(77786)),
	(GetSpellInfo(79339)),
}

local buffs = {
	(GetSpellInfo(91545)),
	(GetSpellInfo(91449)),
	(GetSpellInfo(91518)),
	(GetSpellInfo(91503)),
}

local barrierSpellIdExceptions = {
	2643, -- multishot
	83077, -- improved serpent sting
	44461, -- living bomb (the SPELL_DAMAGE spellId)
}

-- Tank Fail Position in failEvents
local TFP = 5
-- Is Only Overkill Position in generalDamageFail
local IOOP = 6

-------------------------------------------------------------------------
-- API CALLS
-------------------------------------------------------------------------

--- Get a list of supported events.
-- @see failEvents page
-- @return a table of event names which can be fired
function lib:GetSupportedEvents()
	local t = {}
	for k, v in pairs(failEvents) do
		table.insert(t, k)
	end
	return t
end

--- Get a list of supported events in the given zone
-- @see failEvents page
-- @return a table of event names which can be fired in the zone
function lib:GetSupportedZoneEvents(zone) return zoneList[zone] end

--- Get a list of supported events at the given boss
-- @see failEvents page
-- @return a table of event names which can be fired at the boss
function lib:GetSupportedBossEvents(boss) return bossList[boss] end

--- Get a List of Bosses at the given zone for the supported events
-- @see failEvents page
-- @return a table of boss names at the given zone for the supported events
function lib:GetSupportedZoneBosses(zone) return zoneBosses[zone] end

--- Get a List of supported Zones
-- @see failEvents page
-- @return a table of zone names that are supported
function lib:GetSupportedZones()
	local t = {}
	for k, v in pairs(zoneList) do
		table.insert(t, k)
	end
	return t
end

--- Get a fail events localized name
-- @see failEvents page
-- @param event the event name
-- @return a fail events localized name
function lib:GetEventName(event)
	for k, v in pairs(failEvents) do
		if event == k then
			if type(v[3]) == "number" then
				return (GetSpellInfo(v[3]))
			else
				return v[3]
			end
		end
	end
end

--- Get a fail events description
-- @see failEvents in the code
-- @param event the event name
-- @return a description somewhat related to the fail event
function lib:GetEventDescription(event)
	for k, v in pairs(failEvents) do
		if event == k then
			if type(v[4]) == "number" then
				return lib:getSpellDescription(v[4])
			else
				return v[4]
			end
		end
	end
end

--- Get a tabe of constraints with their default values for the event
-- @see lib.CONSTRAINTS
-- @param event the event name
-- @return a table with ["Constraint Name"] = value pairs or returns nil if no constraints
function lib:GetEventConstraints(event)
	for k, v in pairs(lib.CONSTRAINTS) do
		if k == event then
			return v
		end
	end
end

--- Returns true if there is an option for tanks not failing on the event
-- @see failEvents in the code
-- @param event the event name
-- @return true if there is an option for tanks not failing on the event
function lib:GetTanksDontFailOption(event)
	for k, v in pairs(failEvents) do
		if k == event then
			if v[TFP] then
				return true
			end
		end
	end
	return false
end

--- Returns the localized zone for the fail event
-- @see localization strings and babble-zone
-- @param event the fail event to get localized zone for
-- @return the localized zone of the given fail event
function lib:GetLocalizedZone(event)
	for k, v in pairs(zoneList) do
		if event == k then
			if BZ[k] then
				return(BZ[k])
			else
				return "Localization not found"
			end
		end
	end
end

--- Returns the localized boss for the fail event
-- @see localization strings and babble-boss
-- @param event the fail event to get localized boss for
-- @return the localized boss of the given fail event
function lib:GetLocalizedBoss(event)
	for k, v in pairs(bossList) do
		if event == k then
			if BB[k] then
				return(BB[k])
			else
				return "Localization not found"
			end
		end
	end
end

--- Returns the localized constraint name of the given constraint in the given fail event
-- @see lib.CONSTRAINTS
-- @param event, constraint the fail event and the constraint
-- @return the localized constraint name in the given fail event
function lib:GetLocalizedConstraint(event, constraint)
	for k, v in pairs(lib.CONSTRAINTS) do
		if event == k then
			for l, s in pairs(v) do
				if constraint == l then
					return L[constraint]
				end
			end
		end
	end

end

-------------------------------------------------------------------------
-- UTILITY
-------------------------------------------------------------------------

do
	local cache = {}
	local scanner = CreateFrame("GameTooltip")
	scanner:SetOwner(WorldFrame, "ANCHOR_NONE")
	local lCache, rCache = {}, {}
	for i = 1, 4 do
		lCache[i], rCache[i] = scanner:CreateFontString(), scanner:CreateFontString()
		lCache[i]:SetFontObject(GameFontNormal); rCache[i]:SetFontObject(GameFontNormal)
		scanner:AddFontStrings(lCache[i], rCache[i])
	end
	function lib:getSpellDescription(spellId)
		if cache[spellId] then return cache[spellId] end
		scanner:ClearLines()
		scanner:SetHyperlink("spell:"..spellId)
		for i = scanner:NumLines(), 1, -1  do
			local desc = lCache[i] and lCache[i]:GetText()
			if desc then
				cache[spellId] = desc
				return desc
			end
		end
	end
end

function lib:BarrierExceptionCheck(spellId)
	for _, v in ipairs(barrierSpellIdExceptions) do
		if spellId == v then return true
		else
			return false
		end
	end
end

function lib:IsTank(unit)
	-- 1. check blizzard tanks first
	-- 2. check blizzard roles second
	-- 3. finally check LGT for talent guess
	if GetPartyAssignment("MAINTANK", unit, 1) then
		return true
	end
	if UnitGroupRolesAssigned(unit) == "TANK" then
		return true
	end
	local role = LGT:GetUnitRole(unit)
	if role and (role == "tank") then
		return true
	end
	return false
end

function lib:IsDebuffed(target)
	for _, debuff in ipairs(debuffs) do
		if debuff == UnitDebuff(target, debuff) then return true end
	end
	return false
end

function lib:IsBuffed(target)
	for _, buff in ipairs(buffs) do
		if buff == UnitBuff(target, buff) then return true end
	end
	return false
end

function lib:GetMobId(GUID)
	if not GUID then return end
	return tonumber(GUID:sub(7, 10), 16)
end

function lib:findTargetByGUID(id)
	local idType = type(id)
	for i, unit in next, lib.targetlist do
		if UnitExists(unit) and not UnitIsPlayer(unit) then
			local unitId = UnitGUID(unit)
			if idType == "number" then unitId = tonumber(unitId:sub(7, 10), 16) end
			if unitId == id then return unit end
		end
	end
end

do
	frame:Hide()
	frame:SetScript("OnUpdate", function(self, elapsed)
		for name, timer in pairs(lib.timers) do
			timer.elapsed = timer.elapsed + elapsed
			if timer.elapsed > timer.delay then
				timer.func()
				lib:CancelTimer(name)
			end
		end
	end)
end

function lib:ScheduleTimer(name, func, delay)
	if not self.timers then self.timers = {} end
	self.timers[name] = {
		elapsed = 0,
		func = func,
		delay = delay,
	}

	if not frame:IsShown() then frame:Show() end
end

function lib:CancelTimer(name)
	if not name then
		self.timers = {}
		return frame:Hide()
	end

	self.timers[name] = nil
	if not next(self.timers) then self:CancelTimer() end
end

function lib:IsTimerRunning(name)
	return (self.timers and self.timers[name]) and true or false
end

-- param spellId, table
function lib:SpellIdCheck(spellId, table)
	for k, v in pairs(table) do
		for i=1, #v[1] do
			if spellId == v[1][i] then
				return k, unpack(v, 2)
			end
		end
	end
	return false
end

-- range check
function lib:RangeCheck(player)
	local num = GetNumRaidMembers()
	local diff = GetRaidDifficulty()
	for i=1, num do
		local name = GetRaidRosterInfo(i)
		if name == player then
			if diff == 2 or diff == 4 then
				if i > 25 then return false end
			else
				if i > 10 then return false end
			end
		end
	end
	return true
end

function lib:GeneralDamageFail(spellId, destName, damage, overkill)
	local failName, failType, isOnlyOverkill = nil, nil, nil
	if not lib:SpellIdCheck(spellId, generalDamageFail) then
		return
	else
		failName, failType = lib:SpellIdCheck(spellId, generalDamageFail)
		isOnlyOverKill = select(IOOP,lib:SpellIdCheck(spellId, generalDamageFail))
	end

	if overkill > 0 then -- if its an overkill
		self:FailEvent(failName,destName,self[failType]) -- thats a fail either way
	end
	if isOnlyOverKill then return end -- if its only overkill we can stop here
	if failName and self.CONSTRAINTS[failName] then -- the fail has a damage constraint
		if damage > self.CONSTRAINTS[failName]["Damage Constraint"] then -- if damage is higher than constraint value
			self:FailEvent(failName,destName,self[failType])
		end
	else -- if it has no damage constraint
		if damage > 0 then
			self:FailEvent(failName,destName,self[failType])
		end
	end
	return
end

function lib:Antispam(type, min, max, failName, destName, failType, timestamp, ...)
	local deltaT = timestamp - (self.LastEvent[failName][destName] or 0)
	if type then -- Initial damage allowed
		if deltaT > min then -- min time has to pass between two fails
			self:FailEvent(failName, destName, self[failType], ...)
		end
	else -- Initial damage not allowed
		 -- at leat min time has to pass between fails but cant be more than max
		if deltaT > min and deltaT < max then
			self:FailEvent(failName, destName, self[failType], ...)
		end
	end
	self.LastEvent[failName][destName] = timestamp
	return
end

-------------------------------------------------------------------------
-- Initialization
-------------------------------------------------------------------------

function lib:InitVariables()
	if not self.active then return end

	self.RaidTable = {}

	self:InitRaidTable()

	self.LastEvent = {}

	self.targetlist = {"target", "targettarget", "focus", "focustarget", "mouseover", "mouseovertarget"}
	for i = 1, 4 do table.insert(self.targetlist, string.format("boss%d", i)) end
	for i = 1, 4 do table.insert(self.targetlist, string.format("party%dtarget", i)) end
	for i = 1, 40 do table.insert(self.targetlist, string.format("raid%dtarget", i)) end

	-- Last whatever
	for k, v in pairs(failEvents) do
		self.LastEvent[k] = {}
	end

end

function lib:InitRaidTable()
	if next(self.RaidTable) then return end
	local difficulty = GetRaidDifficulty()

	for raidindex = 1, GetNumRaidMembers() do
		local name, _, group, _, _, _, _, online = GetRaidRosterInfo(raidindex)
		if difficulty <= 2 and group <= 2 and online then -- 10 man
			self.RaidTable[name] = false
		elseif group <= 5 and online then -- 25 man
			self.RaidTable[name] = false
		end
	end
end

-------------------------------------------------------------------------
-- Globals
-------------------------------------------------------------------------

lib.FAIL_TYPE_NOTMOVING		= L["not moving"] -- fails at not moving with probably something on him that triggers on movement
lib.FAIL_TYPE_MOVING		= L["moving"] -- fails at moving out of shit
lib.FAIL_TYPE_NOTSPREADING	= L["not spreading"] -- fails at standing together (think auriaya)
lib.FAIL_TYPE_SPREADING		= L["spreading"] -- fails at not having enough distance between people
lib.FAIL_TYPE_DISPELLING	= L["dispelling"] -- fails at not dispelling something you should be dispelling (not very usable yes, but for completeness)
lib.FAIL_TYPE_NOTDISPELLING	= L["not dispelling"] -- fails at dispelling something you should NOT be dispelling
lib.FAIL_TYPE_WRONGPLACE	= L["not being at the wrong place"] -- fails at not being in the wrong place in the wrong time (cleave, etc)
lib.FAIL_TYPE_NOTCASTING	= L["not casting"] -- casting spells when you shouldnt have
lib.FAIL_TYPE_NOTATTACKING	= L["not attacking"] -- attacking when you shouldnt have
lib.FAIL_TYPE_CASTING		= L["casting"] -- not casting spells when you should have (think malygos phase3, or bloodqueen not biting when you should)
lib.FAIL_TYPE_SWITCHING		= L["switching"] -- not taunting/switching tanks when you're supposed to

-- ### Make sure when you add a new constraint type that it has a localization entry
-- ### remember to remove debug events
--- Default constraints
-- @class table
-- @name lib.CONSTRAINTS
-- @field the table holding ["Constraint Type"] = value pairs for failEvents
lib.CONSTRAINTS = {
	--["Fail_Glob -'bal_Maat_HL"] = { ["Damage Constraint"] = 10, ["Tick Constraint"] = 5 },
	["Fail_Blackwing Descent_Magmaw_Pillar of Flame"] = { ["Damage Constraint"] = 40000 },
	["Fail_The Bastion of Twilight_Ascendant Council_Glaciate"] = { ["Damage Constraint"] = 40000 },
	["Fail_The Bastion of Twilight_Valiona and Theralion_Devouring Flames"] = { ["Damage Constraint"] = 50000 },
	["Fail_The Bastion of Twilight_Valiona and Theralion_Twilight Meteorite"] = { ["Damage Constraint"] = 50000 },
	["Fail_Blackwing Descent_Nefarian_Magma"] = { ["Tick Constraint"] = 5 },
	["Fail_Blackwing Descent_Maloriak_Dark Sludge"] = { ["Damage Constraint"] = 400000 },
	["Fail_Blackwing Descent_Omnotron Defense System_Chemical Cloud"] = { ["Time Constraint - Low"] = 5, ["Time Constraint - High"] = 8},
}

lib.TANKS_DONT_FAIL_LIST = {}
for k, v in pairs(failEvents) do
	 if v[TFP] then
		lib.TANKS_DONT_FAIL_LIST[k] = true
	end
end

-------------------------------------------------------------------------
-- EVENT HANDLING
-------------------------------------------------------------------------

do
	local _, etype, f

	frame:SetScript("OnEvent", function (self, event, ...)
		if event == "COMBAT_LOG_EVENT_UNFILTERED" then
			_, etype = ...
			if etype == "SPELL_MISSED" then  -- lets hack the misses onto the damage event
				local timestamp, _, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, missType,  amountMissed = ...
				local damage, overkill = 0, 0

				lib.SPELL_DAMAGE(lib, timestamp, etype, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, damage, overkill, missType, amountMissed)

				return
			end

			f = lib[etype]

			if f then
				f(lib, ...)
			end

			return
		end

		f = lib[event]

		if f then
			f(lib, ...)
		end

	end)
end

function lib:FailEvent(event, playerName, failType, ...)
	if lib.TANKS_DONT_FAIL_LIST[event] and lib:IsTank(playerName) then return end
	if not lib:RangeCheck(playerName) then return end
	-- Don't fire if one of the arguments are missing
	if not playerName or playerName=="" or not failType or failType=="" or not event or event=="" then return end
	callbacks:Fire(event, playerName, failType, ...)
	callbacks:Fire("AnyFail", event, playerName, failType, ...)
end

function lib:GoActive()
	if self.active then return end

	frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	frame:RegisterEvent("PLAYER_REGEN_ENABLED")
	frame:RegisterEvent("CHAT_MSG_MONSTER_EMOTE")
	self:InitVariables()

	self.active = true

	callbacks:Fire("Fail_Active")
end

function lib:GoInactive()
	if not self.active then return end

	self:InitVariables()

	self.active = nil

	frame:RegisterEvent("RAID_ROSTER_UPDATE")
	frame:UnregisterEvent("CHAT_MSG_MONSTER_EMOTE")
	frame:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	frame:UnregisterEvent("PLAYER_REGEN_ENABLED")

	callbacks:Fire("Fail_Inactive")
end

lib.active = true
lib:GoInactive()

function lib:PLAYER_ENTERING_WORLD()
	if GetNumRaidMembers() > 0 then
		self:GoActive()
	else
		self:GoInactive()
	end
end

function lib:RAID_ROSTER_UPDATE()
	if GetNumRaidMembers() > 0 then
		self:GoActive()
	else
		self:GoInactive()
	end
end

function lib:PLAYER_REGEN_ENABLED()
	self:InitVariables()
end

function lib:CHAT_MSG_MONSTER_EMOTE(message, sourceName, language, channelName, destName, ...)

end


function lib:SPELL_DAMAGE(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, damage, overkill)
	if bit.band(sourceFlags or 0, COMBATLOG_OBJECT_TYPE_GUARDIAN) > 0 or bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_GUARDIAN) > 0 or not spellId then return end
	-- Guardian activities ignored after this point
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0
	damage = damage ~= "ABSORB" and damage or 0
	overkill = overkill or 0

	if isPlayerEvent then lib:GeneralDamageFail(spellId, destName, damage, overkill) end

	local destUnitID = lib:findTargetByGUID(destGUID)
	if destUnitID and lib:IsBuffed(destUnitID) and not lib:BarrierExceptionCheck(spellId) then
		if UnitIsUnit("boss1",destUnitID) or UnitIsUnit("boss2",destUnitID) or UnitIsUnit("boss3",destUnitID) or UnitIsUnit("boss4",destUnitID) then
			lib:Antispam(true, 5, nil, "Fail_Blackwing Descent_Omnotron Defense System_Barrier", sourceName, "FAIL_TYPE_NOTATTACKING", timestamp, spellName)
		end
	end

	if spellName == (GetSpellInfo(94113)) then -- lightning discharge
		self.LastEvent["Lightning Discharge"] = timestamp
	end

	if lib:SpellIdCheck(spellId, failEvents) and isPlayerEvent then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_The Bastion of Twilight_Valiona and Theralion_Deep Breath" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Valiona and Theralion_Twilight Meteorite" and damage > self.CONSTRAINTS[failName]["Damage Constraint"] then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Ascendant Council_Lava Plume" and damage > 0 then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Ascendant Council_Flame Strike" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Valiona and Theralion_Devouring Flames" and damage > self.CONSTRAINTS[failName]["Damage Constraint"] then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Magmaw_Massive Crash" and damage > 0 then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Ascendant Council_Flame Torrent" and damage > 0 then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Nefarian_Shadow Of Cowardice" and damage > 0 then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Magmaw_Pillar of Flame" and damage > self.CONSTRAINTS[failName]["Damage Constraint"] then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Magmaw_Ignition" and damage > 0 then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Maloriak_Scorching Blast" then
			if lib:IsDebuffed(destName) and damage > 0 then
				self:FailEvent("Fail_Blackwing Descent_Maloriak_Consuming Flames",destName,self.FAIL_TYPE_MOVING)
				return
			else
				self.RaidTable[destName] = timestamp
			end
		elseif failName == "Fail_Blackwing Descent_Omnotron Defense System_Chemical Cloud" then
			lib:Antispam(false, self.CONSTRAINTS[failName]["Time Constraint - Low"] , self.CONSTRAINTS[failName]["Time Constraint - High"] , failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Maloriak_Engulfing Darkness" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Omnotron Defense System_Arcane Blowback" and damage > 0 then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Maloriak_Magma Jets" then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Maloriak_Absolute Zero" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Throne of the Four Winds_Conclave of Wind_Wind Blast" and damage > 0 then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Cho'gall_Blaze" then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Cho'gall_Corrupting Crash" then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Throne of the Four Winds_Conclave of Wind_Permafrost" then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Nefarian_Shadowblaze" and damage > 0 then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Sinestra_Twilight Slicer" and overkill > 0 then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Sinestra_Twilight Extinction" and overkill > 0 then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_The Bastion of Twilight_Sinestra_Twilight Pulse" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Nefarian_Tail Lash" then
			self:ScheduleTimer("Nefarian_Tail Lash", function()
				if self.LastEvent["Lightning Discharge"] then
					if timestamp - self.LastEvent["Lightning Discharge"] > 5 then
						self:FailEvent(failName,destName,self.FAIL_TYPE_MOVING)
						return
					end
				end
			end, 2)

		end
	end
end

function lib:SWING_DAMAGE(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, damage, overkill)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0
	damage = damage ~= "ABSORB" and damage or 0
	overkill = overkill or 0

--11/6 18:20:23.374  SWING_DAMAGE,0xF130AABB00002A66,"Blood of the Old God",0xa48,0x0100000000509499,"Mackzter",0x514,14238,-1,32,6102,0,0,nil,nil,nil
--Might need to add it to SWING_MISSED too if it turns out that misses make you go even more insane
	if self:GetMobId(sourceGUID) == 43707 and isPlayerEvent then
		lib:Antispam(true, 3, nil, "Fail_The Bastion of Twilight_Cho'gall_Blood", destName, "FAIL_TYPE_MOVING", timestamp)
		return
	end

	if self:GetMobId(sourceGUID) == 42897 and isPlayerEvent then
		lib:Antispam(true, 3, nil, "Fail_Blackwing Descent_Omnotron Defense System_Poison Bomb", destName, "FAIL_TYPE_MOVING", timestamp)
		return
	end

	local destUnitID = lib:findTargetByGUID(destGUID)
	if destUnitID and lib:IsBuffed(destUnitID) then
		if UnitIsUnit("boss1",destUnitID) or UnitIsUnit("boss2",destUnitID) or UnitIsUnit("boss3",destUnitID) or UnitIsUnit("boss4",destUnitID) then
			lib:Antispam(true, 5, nil, "Fail_Blackwing Descent_Omnotron Defense System_Barrier", sourceName, "FAIL_TYPE_NOTATTACKING", timestamp, (GetSpellInfo(5547))) -- Swing
		end
	end

end

function lib:SWING_MISSED(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0

	if self:GetMobId(sourceGUID) == 43707 and isPlayerEvent then
		lib:Antispam(true, 3, nil, "Fail_The Bastion of Twilight_Cho'gall_Blood", destName, "FAIL_TYPE_MOVING", timestamp)
		return
	end

	if self:GetMobId(sourceGUID) == 42897 and isPlayerEvent and GetRaidDifficulty()%2 == 0 then -- Lets allow using immunity/deterrance/whatever in 10 mans
		lib:Antispam(true, 3, nil, "Fail_Blackwing Descent_Omnotron Defense System_Poison Bomb", destName, "FAIL_TYPE_MOVING", timestamp)
		return
	end

end

function lib:SPELL_INTERRUPT(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, interruptedSpellId, interruptedSpellName, interruptedSpellSchool)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0

	--12/22 20:53:36.024  SPELL_INTERRUPT,0x05000000032FE2ED,"Stekharn",0x514,0xF150A4B60000104B,"Arcanotron",0x10a48,1766,"Kick",0x1,91542,"Arcane Annihilator",64
	if self:GetMobId(destGUID) == 42166 then
		self.LastEvent["Fail_Blackwing Descent_Omnotron Defense System_Barrier"][sourceName] = timestamp
	end

end

function lib:SPELL_CAST_START(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool)
-- ### remember to remove debug events
--[===[@debug@
--[[
	if lib:SpellIdCheck(spellId, failEvents) then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_Glob -'bal_Ca 'leb_Dismiss Pet" then
			lib:Antispam(true, 1, nil, failName, sourceName, failType, timestamp)
		elseif failName == "Fail_Glob -'bal_Maat_HL" then
			lib:Antispam(true, 1, nil, failName, sourceName, failType, timestamp)
		end
	end
	]]--
--@end-debug@]===]
end

function lib:UNIT_DIED(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0
	local mobid = self:GetMobId(destGUID)

end

function lib:SPELL_PERIODIC_DAMAGE(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, damage, overkill)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0
	damage = damage ~= "ABSORB" and damage or 0
	overkill = overkill or 0

	if isPlayerEvent then lib:GeneralDamageFail(spellId, destName, damage, overkill) end

	if lib:SpellIdCheck(spellId, failEvents) and isPlayerEvent then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_Throne of the Four Winds_Al'Akir_Squall Line" then
			lib:Antispam(true, 12, nil, failName, destName, failType, timestamp) -- 12 might not be enough
			return
		elseif failName == "Fail_Throne of the Four Winds_Conclave of Wind_Toxic Spores" then
			lib:Antispam(true, 5, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Maloriak_Dark Sludge" and damage > 0 then
			if overkill > 0 then
				self:FailEvent(failName,destName,self[failType])
			else
				if self.LastEvent[failName][destName] then
					self.LastEvent[failName][destName] = self.LastEvent[failName][destName] + damage
				else
					self.LastEvent[failName][destName] = damage
				end
				if self.LastEvent[failName][destName] > self.CONSTRAINTS[failName]["Damage Constraint"] then
					self:FailEvent(failName,destName,self[failType])
					self.LastEvent[failName][destName] = nil
				end
			end
			return
		end
	end

end

function lib:SPELL_HEAL(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, damage)
	-- local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0

end

function lib:SPELL_AURA_APPLIED(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0

	if lib:SpellIdCheck(spellId, failEvents) and isPlayerEvent then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_The Bastion of Twilight_Ascendant Council_Frozen" then
			self:FailEvent(failName,destName,self[failType])
		elseif failName == "Fail_Blackwing Descent_Magmaw_Parasitic Infection" then
			self:FailEvent(failName,destName,self[failType])
		elseif failName == "Fail_Blackwing Descent_Maloriak_Consuming Flames" then
			self.RaidTable[destName] = false
		end
	end

end

function lib:SPELL_AURA_APPLIED_DOSE(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType, stack)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0

	if lib:SpellIdCheck(spellId, failEvents) and isPlayerEvent then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_Blackwing Descent_Nefarian_Magma" and stack == self.CONSTRAINTS[failName]["Tick Constraint"] then
			if self:IsDebuffed(destName) or not UnitAffectingCombat(destName) then return end
			if GetInstanceDifficulty() > 2 then
				if self.RaidTable[destName] then
					if (timestamp - self.RaidTable[destName]) > 3 then
						self:FailEvent(failName,destName,self[failType])
					end
				else
					self:FailEvent(failName,destName,self[failType])
				end
			else
				self:FailEvent(failName,destName,self[failType])
			end
		end
	end

end

function lib:SPELL_CAST_SUCCESS(timestamp, event, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool)

	if lib:SpellIdCheck(spellId, failEvents) then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_Blackwing Descent_Maloriak_Scorching Blast" then
			self:ScheduleTimer("Maloriak_Scorching Blast", function()
				for name, lastTime in pairs(lib.RaidTable) do
					if lib:IsDebuffed(name) then return end
					if type(lastTime) == "number" and not UnitIsDeadOrGhost(name) then
						if (timestamp - lastTime) > 4 then
							self:FailEvent(failName,name,self[failType])
						end
					elseif type(lastTime) == "boolean" and not UnitIsDeadOrGhost(name) then
						self:FailEvent(failName,name,self[failType])
					end
				end
				lib:InitRaidTable()
			end, 1)
			return
		end
	end

end

function lib:SPELL_ENERGIZE(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, amount, powerType)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0

	if lib:SpellIdCheck(spellId, failEvents) then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_Blackwing Descent_Atramedes_Sonar Pulse" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Atramedes_Sonar Bomb" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		elseif failName == "Fail_Blackwing Descent_Atramedes_Sonic Breath" then
			lib:Antispam(true, 3, nil, failName, destName, failType, timestamp)
			return
		end
	end
end

function lib:SPELL_DISPEL(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, extraSpellId, extraSpellName)

end

function lib:SPELL_AURA_REMOVED(timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool)
	local isPlayerEvent = bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) > 0

	if spellId == 79339 then
		self.RaidTable[destName] = timestamp
	end

	if lib:SpellIdCheck(spellId, failEvents) and isPlayerEvent then
		local failName, failType = lib:SpellIdCheck(spellId, failEvents)
		if failName == "Fail_Blackwing Descent_Maloriak_Consuming Flames" then
			self.RaidTable[destName] = timestamp
		end

	end
end

