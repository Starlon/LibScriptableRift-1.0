local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("StarVisuals", "enUS", true, true)
if not L then return end

L["Welcome to "] = true
L[" Type /starvisuals to open config. Alternatively you could press escape and choose the addons menu. Or you can choose to show a minimap icon."] = true
